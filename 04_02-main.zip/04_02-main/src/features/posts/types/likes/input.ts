export type LikeStatus = 'None' | 'Like' | 'Dislike';
