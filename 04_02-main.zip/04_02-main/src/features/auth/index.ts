import { AuthService } from './service/auth.service';

export const authProviders = [AuthService];
