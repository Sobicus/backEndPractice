export type UserOutputType = {
  id: string;
  login: string;
  email: string;
  createdAt: string;
};
