export type NewestLikeType = {
  addedAt: string;
  userId: string;
  login: string;
};
